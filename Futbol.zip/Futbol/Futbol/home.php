<?php
session_start();

require './config/conex.php';


if (isset($_SESSION['user_id'])){
    $records = $conn -> prepare('SELECT id, email, password FROM users WHERE id = :id');
    $records -> bindParam(':id', $_SESSION['user_id']);
    $records ->execute();
    $results = $records ->fetch(PDO::FETCH_ASSOC);
    $user = null;

    if (count($results) > 0) {
        $user = $results;
    }
}
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
    <?php if (!empty($user)): ?>
    <br> Welcome. <?= $user['email'] ?>
    <br>You are succesfully logged in 
    <a href="./login/logout.php">Logout</a>
    <?php else: ?>
        <h1>Please Login or signup</h1>
        <a href="./login/index.php"></a>
        <a href="./login/signup.php"></a>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <?php endif; ?>
  </body>
</html>