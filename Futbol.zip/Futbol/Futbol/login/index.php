<?php
  session_start();
  if(isset($_SESSION['user_id'])) {

    header('Location: index.php');
  }


  require '../config/conex.php';
  /////////////////////////////////
  if (!empty($_POST['email']) && !empty($_POST['password'])) {
    $records = $conn->prepare('SELECT id, email, password FROM users WHERE email = :email');
    $records->bindParam(':email', $_POST['email']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);
    $message = '';
    if (count($results) > 0 && password_verify($_POST['password'], $results['password'])) {
      $_SESSION['user_id'] = $results['id'];
      header("Location: ../home.php");
    } else {
      $message = 'Lo sentimos, las credenciales no se pudieron encontrar';
    }
    
  }


?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <link rel="stylesheet" href="../style.css">
    <title>LOG IN</title>
  </head>
  <body>
    <div class="box">
        <div class="form">
          <form action="" method="post">
            <h2>Login</h2>
            <?php 
            if(!empty($message)) :?>
            <p><?= $message ?></p>
            <?php endif; ?>



            <div class="inputBox">
                <input type="email" required="required" name="email">
                <span>User</span>
                <i></i>
            </div>
            <div class="inputBox">
                <input type="password" required="required" name="password">
                <span>Password</span>
                <i></i>
            </div>
            <div class="links">
              <a href="#">Forgot Password</a>
              <a href="signup.php">Register</a>
          </div>
            <input type="submit" value="Iniciar">
            </form>
        </div>
    </div>
  </body>
</html>