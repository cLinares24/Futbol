<?php
$server = 'localhost';
$username = 'root';
$password = 'root';
$database = 'usuario';


// Ahora, establecemos la conexión.
try
{
$conn = new PDO("mysql:host=".$server.";dbname=".$database,$username, $password);
}
catch (PDOException $e)
{
die("Error: " . $e->getMessage());
}


?>