<?php

$message = '';
require '../config/database.php';


if (!empty($_POST['email']) && !empty($_POST['password'])) {
  $sql = "INSERT INTO users (email, password) VALUES (:email, :password)";
  $stmt = $PDO->prepare($sql);
  $stmt->bindParam(':email', $_POST['email']);
  $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
  $stmt->bindParam(':password', $password);

  if ($stmt->execute()) {
    $message = 'El usuario se creó correctamente';
  } else {
    $message = 'Sorry there must have been an issue creating your account';
  }
}
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="../style2.css">
    <title>Registro</title>
  </head>
  <body>
  <h1>Registro</h1>
      
      <div class="login">
<form action="signup.php" method="post">
  <h2 class="active"> sign Up </h2>
  <a class="h2" href="../index2.php">Login</a>
  <form>

    <input type="text" class="text" name="email">
    <span>Correo electrónico</span>

    <br>

    <br>

    <input type="password" class="text" name="password">
    <span>contraseña</span>
    <br>
    <br>
    <input type="password" class="text" name="confirm_password">
    <span>Repetir contraseña</span>
    <br>
    
    

    <button class="signin" type="submit" value="send">
      Sign In
    </button>

    <hr>


  </form>
</div>
<?php
    if(!empty($message)):
    ?>
    <p><?= $message ?></p>
    <?php endif; ?>




   
  </body>
</html>

