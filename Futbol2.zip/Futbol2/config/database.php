<?php
$server = 'localhost';
$username = 'root';
$password = 'root';
$database = 'usuario';


// Ahora, establecemos la conexión.
try{
$PDO = new PDO("mysql:host=".$server.";dbname=".$database,$username, $password);
$PDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}catch (PDOException $e){

    echo "Error en la conexión: " . $e->getMessage();

}
?>