<?php
    class db{
        private $host= "localhost";
        private $dbname="usuario";
        private $user="root";
        private $password="root";
        public $PDO;


        public function conexion(){
            try{
                $PDO = new PDO("mysql:host=".$this->host.";dbname=".$this->dbname,$this->user,$this->password);
                return $PDO;
            }catch(PDOException $e){
                return $e->getMessage();
            }
        }

        public function obtenerPDO() {
            return $this->PDO;
        }
    }

?>