<?php

class usernameModel{
    private $PDO;

    public function __construct(){
        require_once ("C:/xampp/htdocs/Futbol2/config/db.php");
        $con = new db();
        $this->PDO = $con->conexion();
    }

    public function insertar($nombre, $edad, $apellido, $peso, $identificacion, $telefono, $nacionalidad, $ciudad, $posicion,   $pie, $cuenta, $goles, $lesiones, $sangre, $dorsal, $altura) {
        $stament = $this ->PDO->prepare("INSERT INTO players VALUES (null, :nombre, :edad, :apellido, :peso, :identificacion, :telefono, :nacionalidad, :ciudad, :posicion, :pie, :cuenta, :goles, :lesiones, :sangre, :dorsal,  :altura)");
        $stament ->  bindParam(":nombre" ,$nombre );
        $stament ->  bindParam(":edad" ,$edad );
        $stament ->  bindParam(":apellido" ,$apellido );
        $stament ->  bindParam(":peso" ,$peso );
        $stament ->  bindParam(":identificacion" ,$identificacion );
        $stament ->  bindParam(":telefono" ,$telefono );
        $stament ->  bindParam(":nacionalidad" ,$nacionalidad );
        $stament ->  bindParam(":ciudad" ,$ciudad );
        $stament ->  bindParam(":posicion" ,$posicion );
        $stament ->  bindParam(":pie" ,$pie );
        $stament ->  bindParam(":cuenta" ,$cuenta );
        $stament ->  bindParam(":goles" ,$goles );
        $stament ->  bindParam(":lesiones" ,$lesiones );
        $stament ->  bindParam(":sangre" ,$sangre );
        $stament ->  bindParam(":dorsal" ,$dorsal );
        $stament ->  bindParam(":altura" ,$altura );
        return ($stament ->execute()) ? $this ->PDO->lastInsertId() : false ;
    }

    public function show($id) {
        $stament = $this -> PDO->prepare("SELECT * FROM players where id = :id limit 1");
        $stament ->bindParam(":id", $id);
        return ($stament ->execute()) ? $stament ->fetch() : false ;
    }

    public function index() {
        $stament = $this -> PDO ->prepare("SELECT * FROM players");
        return ($stament ->execute()) ? $stament ->fetchAll() : false;
    }

    public function update ($id, $nombre, $edad, $apellido, $peso, $identificacion, $telefono, $nacionalidad, $ciudad, $posicion, $pie, $cuenta, $goles, $lesiones, $sangre, $dorsal, $altura) {
        $stament = $this ->PDO->prepare("UPDATE players SET nombres = :nombres, edad = :edad, apellidos = :apellidos, peso = :peso, identificacion = :identificacion, telefono = :telefono, nacionalidad = :nacionalidad, ciudad = :ciudad, posicion = :posicion, pie = :pie, cuenta = :cuenta, goles = :goles, lesiones = :lesiones, sangre = :sangre, dorsal = :dorsal, altura = :altura WHERE id = :id");
        $stament ->  bindParam(":nombres" ,$nombre);
        $stament ->  bindParam(":id" ,$id);
        $stament ->  bindParam(":edad" ,$edad );
        $stament ->  bindParam(":apellidos" ,$apellido );
        $stament ->  bindParam(":peso" ,$peso );
        $stament ->  bindParam(":identificacion" ,$identificacion );
        $stament ->  bindParam(":telefono" ,$telefono );
        $stament ->  bindParam(":nacionalidad" ,$nacionalidad );
        $stament ->  bindParam(":ciudad" ,$ciudad );
        $stament ->  bindParam(":posicion" ,$posicion );
        $stament ->  bindParam(":pie" ,$pie );
        $stament ->  bindParam(":cuenta" ,$cuenta );
        $stament ->  bindParam(":goles" ,$goles );
        $stament ->  bindParam(":lesiones" ,$lesiones );
        $stament ->  bindParam(":sangre" ,$sangre );
        $stament ->  bindParam(":dorsal" ,$dorsal );
        $stament ->  bindParam(":altura" ,$altura );

        
        return ($stament ->execute()) ? $id : false;
    }

    public function delete($id) {
        $stament = $this ->PDO->prepare("DELETE FROM players WHERE id = :id");
        $stament->bindParam(":id" ,$id);
        return ($stament->execute()) ? true : false;

    }

}
