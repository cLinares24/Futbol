<?php
require_once("../usernameController.php");
$obj = new usernameController();
$obj->update($_POST['id'], $_POST['nombre'], $_POST['edad'], $_POST['apellido'], $_POST['peso'], $_POST['identificacion'], $_POST['telefono'], $_POST['nacionalidad'], $_POST['ciudad'], $_POST['posicion'], $_POST['pie'], $_POST['cuenta'], $_POST['goles'], $_POST['lesiones'], $_POST['sangre'], $_POST['dorsal'], $_POST['altura']);
?>