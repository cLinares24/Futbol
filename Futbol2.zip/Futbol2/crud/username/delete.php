<?php
require_once ("c://xampp/htdocs/Futbol2/crud/usernameController.php");

$obj = new usernameController();
$obj->delete($_GET['id']);


?>