<?php
require_once("../head.php");
require_once("../usernameController.php");
$obj = new usernameController();
$user = $obj->show($_GET['id']);
?>
<form action="update.php" method="POST" autocomplete="off">
    <h2>Modificando Registro</h2>
    <div class="mb-3 row">
        <label for="staticEmail" class="col-sm-2 col-form-label">Id</label>
        <div class="col-sm-10">
        <input type="text" name="id" readonly class="form-control-plaintext" id="staticEmail" value="<?= $user[0]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nuevo Nombre</label>
        <div class="col-sm-10">
            <input type="text" name="nombre" class="form-control" id="inputPassword" value="<?= $user[1]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nueva edad</label>
        <div class="col-sm-10">
            <input type="text" name="edad" class="form-control" id="inputPassword" value="<?= $user[2]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nuevos apellidos</label>
        <div class="col-sm-10">
            <input type="text" name="apellido" class="form-control" id="inputPassword" value="<?= $user[3]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nuevo peso</label>
        <div class="col-sm-10">
            <input type="text" name="peso" class="form-control" id="inputPassword" value="<?= $user[4]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nueva Identificacion</label>
        <div class="col-sm-10">
            <input type="text" name="identificacion" class="form-control" id="inputPassword" value="<?= $user[5]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nuevo Teléfono</label>
        <div class="col-sm-10">
            <input type="text" name="telefono" class="form-control" id="inputPassword" value="<?= $user[6]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nueva nacionalidad</label>
        <div class="col-sm-10">
            <input type="text" name="nacionalidad" class="form-control" id="inputPassword" value="<?= $user[7]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nueva ciudad</label>
        <div class="col-sm-10">
            <input type="text" name="ciudad" class="form-control" id="inputPassword" value="<?= $user[8]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nueva posicion</label>
        <div class="col-sm-10">
            <input type="text" name="posicion" class="form-control" id="inputPassword" value="<?= $user[9]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nuevo pié</label>
        <div class="col-sm-10">
            <input type="text" name="pie" class="form-control" id="inputPassword" value="<?= $user[10]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nueva Cuenta</label>
        <div class="col-sm-10">
            <input type="text" name="cuenta" class="form-control" id="inputPassword" value="<?= $user[11]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nuevos Goles</label>
        <div class="col-sm-10">
            <input type="text" name="goles" class="form-control" id="inputPassword" value="<?= $user[12]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nuevas Lesiones</label>
        <div class="col-sm-10">
            <input type="text" name="lesiones" class="form-control" id="inputPassword" value="<?= $user[12]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nueva sangre</label>
        <div class="col-sm-10">
            <input type="text" name="sangre" class="form-control" id="inputPassword" value="<?= $user[13]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nuevo Dorsal</label>
        <div class="col-sm-10">
            <input type="text" name="dorsal" class="form-control" id="inputPassword" value="<?= $user[15]?>">
        </div>
    </div>
    <div class="mb-3 row">
        <label for="inputPassword" class="col-sm-2 col-form-label">Nueva altura</label>
        <div class="col-sm-10">
            <input type="text" name="altura" class="form-control" id="inputPassword" value="<?= $user[16]?>">
        </div>
    </div>
    <div>
        <input type="submit" class="btn btn-success" value="Actualizar">
        <a class="btn btn-danger" href="show.php?id=<?= $user[0]?>">Cancelar</a>
    </div>
  </form>

<?php
require_once("../footer.php");

?>