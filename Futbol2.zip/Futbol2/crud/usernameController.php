<?php

    class usernameController {
        private $model;
        
        public function __construct(){
            require_once ("usernameModel.php");
            $this ->model = new usernameModel();
        }

        public function guardar ($nombre, $edad, $apellidos, $peso, $identificacion, $telefono, $nacionalidad, $ciudad, $posicion, $pie, $cuenta, $goles, $lesiones, $sangre, $dorsal, $altura) {
            $id = $this->model->insertar(
                $nombre,
                $edad,
                $apellidos,
                $peso,
                $identificacion,
                $telefono,
                $nacionalidad,
                $ciudad,
                $posicion,
                $pie,
                $cuenta,
                $goles,
                $lesiones,
                $sangre,
                $dorsal,
                $altura
            );

            return ($id!=false) ? header("Location:show.php?id".$id) : header("Location:create.php");
        }

        public function show ($id) {
            return ($this ->model->show($id) != false) ? $this ->model->show($id) : header("Location:index.php");
        }

        public function index() {
            return ($this ->model->index()) ? $this->model->index() : false;
        }

        public function update($id, $nombre, $edad, $apellido, $peso, $identificacion, $telefono, $nacionalidad, $ciudad, $posicion, $pie, $cuenta, $goles, $lesiones, $sangre, $dorsal, $altura) {

            return ($this->model->update($id, $nombre, $edad, $apellido, $peso, $identificacion, $telefono, $nacionalidad, $ciudad, $posicion, $pie, $cuenta, $goles, $lesiones, $sangre, $dorsal, $altura)  != false  ) ? header("Location:show.php?id".$id) : header("Location:index.php");
        }

        public function delete($id) {
            return ($this->model->delete($id)) ? header("Location:index.php") : header("Location:show.php?id".$id);


        }


    }

    ?>