<?php
session_start();

require './config/database.php';


if (isset($_SESSION['user_id'])){
    $records = $PDO -> prepare('SELECT id, email, password FROM users WHERE id = :id');
    $records -> bindParam(':id', $_SESSION['user_id']);
    $records ->execute();
    $results = $records ->fetch(PDO::FETCH_ASSOC);
    $user = null;

    if (count($results) > 0) {
        $user = $results;
    }
}
?>


<?php if (!empty($user)): ?>

<?php
    require_once("c://xampp/htdocs/Futbol2/crud/head.php");
?>

<link rel="stylesheet" href="style2.css">
<a href="/Futbol2/crud/username/create.php" class="btn btn-primary">Agregar nuevo usuario</a>
<?php
    require_once("c://xampp/htdocs/Futbol2/crud/footer.php");
?>
<a class="h2" href="./login/logout.php">Logout</a>


<?php else: ?>
        <h1>Please Login or signup</h1>
        <a href="index2.php"></a>
        <a href="signup.php"></a>

<?php endif; ?>
