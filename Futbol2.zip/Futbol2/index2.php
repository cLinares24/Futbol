<?php
  session_start();
  if(isset($_SESSION['user_id'])) {

    header("c://xampp/htdocs/Futbol2/index2.php");
  }



  require ('config/database.php');




  if (!empty($_POST['email']) && !empty($_POST['password'])) {
    $records = $PDO->prepare('SELECT id, email, password FROM users WHERE email = :email');
    $records->bindParam(':email', $_POST['email']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);
    $message = '';
  
    if ($results !== false && password_verify($_POST['password'], $results['password'])) {
      $_SESSION['user_id'] = $results['id'];
      header("Location: index.php");
      exit(); // Agregamos exit() después de redireccionar para detener la ejecución del script.
    } else {
      $message = 'las credenciales no se pudieron encontrar';
    }
  }
  


?>





<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Inicio de sesión</title>
  <link rel="stylesheet" href="./style.css">

</head>
<body>
<div class="contenedor-padre"> 
  <!--Inicializamos la cámara dentro de un contenedor-->
    <div class='container2'>       
        <div class='camera-top'>
        <div class='zoom'></div>
        <div class='mode-changer'></div>
        <div class='sides'></div>
        <div class='range-finder'></div>
        <div class='focus'></div>
        <div class='red'></div>
        <div class='view-finder'></div>
        <div class='flash'>
        <div class='light'></div>
    </div>
    </div>
  <div class='camera-mid'>
    <div class='sensor'></div>
    <div class='lens'></div>
  </div>
  <div class='camera-bottom'></div>
    </div>
    <!--Inicializamos el formulario-->
    <div class="container">
      <div class="box">
        <div class="form">
          <form method="POST" action="">
            <h2>Login</h2>
            <?php 
            if(!empty($message)) :?>
            <p><?= $message ?></p>
            <?php endif; ?>


            <div class="inputBox">
                <input type="text" required="required" name="email" >
                <span>User</span>
                <i></i>
            </div>
            <div class="inputBox">
                <input type="password" required="required" name="password">
                <span>Password</span>
                <i></i>
            </div>
            <div class="links">
              <a href="#">Forgot Password</a>
              <a href="./login/signup.php">Register</a>
          </div>
            <input type="submit" value="Iniciar">
            </form>
        </div>
       </div>
      </div>
    </div>
</body>
</html>