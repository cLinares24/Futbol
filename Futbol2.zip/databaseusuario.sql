-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: usuario
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `players` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombres` varchar(200) DEFAULT NULL,
  `apellidos` varchar(200) DEFAULT NULL,
  `edad` varchar(200) DEFAULT NULL,
  `altura` varchar(200) DEFAULT NULL,
  `peso` varchar(200) DEFAULT NULL,
  `dorsal` varchar(200) DEFAULT NULL,
  `telefono` varchar(200) DEFAULT NULL,
  `nacionalidad` varchar(200) DEFAULT NULL,
  `ciudad` varchar(200) DEFAULT NULL,
  `posicion` varchar(200) DEFAULT NULL,
  `pie` varchar(200) DEFAULT NULL,
  `cuenta` varchar(200) DEFAULT NULL,
  `goles` varchar(200) DEFAULT NULL,
  `lesiones` varchar(200) DEFAULT NULL,
  `sangre` varchar(200) DEFAULT NULL,
  `identificacion` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `players`
--

LOCK TABLES `players` WRITE;
/*!40000 ALTER TABLE `players` DISABLE KEYS */;
INSERT INTO `players` VALUES (27,'Camilo','17','Linares Murillo','1054','110','3','9','301531','colombi','manila','dc','der','4093***','4093***','874','75');
/*!40000 ALTER TABLE `players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `username`
--

DROP TABLE IF EXISTS `username`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `username` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `username`
--

LOCK TABLES `username` WRITE;
/*!40000 ALTER TABLE `username` DISABLE KEYS */;
INSERT INTO `username` VALUES (13,'Camilo');
/*!40000 ALTER TABLE `username` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'canonblast123@gmail.com','$2y$10$0.d0s.Tynodx1SYpZzUH2.8ypKcnASrzAwtLEuLkj3gt73s4szgeK'),(2,'Will@mail','potos123'),(3,'xdcami2@gmail.com','$2y$10$tIQEj3lKAOMjlaHWokXJHud84JXUrjysyPdO6tZyfG18nsBmVyfB.'),(4,'cami','$2y$10$Rgzo.2EaU5UfdUg.MKRyzuNgdoRKClaNIIZ3x1UyHs6q7CEX.WriO'),(5,'cami','$2y$10$oazXsUt3EKQ4dVBhizCgHeHOi/IK2p2oWzjLzCzYF4qkNlrG14gky'),(6,'camilo','$2y$10$EV2sRfU5wHYARZ2E1UoLl.w2pl9GmCvEiqj7yj8nmtPn3lXZA7dcS'),(7,'camilo','$2y$10$cxXftHZ5hKiXOehmhei2/uBy8PKJErsO50w4Is/6tejpzeqQeAaBm'),(8,'camilo','$2y$10$ggBHkb5Fxr.lBg6FjbCfaewvaF7u5e3d.BBYGMsYM.hUXNoJ2HgxW'),(9,'ola','$2y$10$8U42itX464bACr3ayNbsk.go7n69d3W8QViijf5RROgJPeAMNzofK'),(10,'olis','$2y$10$a2g4IrTWkUVsI.EwEV64lurIjLQwTYByO9eBXaXh.P055O87brjqG');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'usuario'
--

--
-- Dumping routines for database 'usuario'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-20 19:08:16
